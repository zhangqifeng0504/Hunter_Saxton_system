%% 空间阶
clear all; clc; format short e
n =1000; 
xa = -6; xb = 6; ta =0; tb = 20; a = 0.1; A = 0; mu = 0; sigma = 1;%CaseI
%xa = -6; xb = 6; ta =0; tb = 20; a = 0.1; A = 0.1; mu = 0; sigma = 1;%CaseII
%xa = -6; xb = 6; ta =0; tb = 20; a = 0.1; A = 0.1; mu = 0.015; sigma = 1;%CaseIII
%xa = -6; xb = 6; ta =0; tb = 1; a = 4; A = 0; mu = 0; sigma = 1;%CaseIV
for i = 1:5
    tic
    m =50*2.^(i-1); 
   [u1,rho1]=HS_3(A,sigma,mu,a,xa,xb,ta,tb,m,n);
   [u2,rho2]=HS_3(A,sigma,mu,a,xa,xb,ta,tb,2*m,n);
    u_Error = abs(u1(:,end) - u2(1:2:end,end));
   p_Error = sqrt((abs(xb-xa)/m)*sum((rho1(:,end) - rho2(1:2:end,end)).^2));
    u_MaxErr(i) = max(u_Error)
    p_MaxErr(i) = max(p_Error)
    cputime(i)=toc;
end
u_Ord = log2(u_MaxErr(1:end-1)./u_MaxErr(2:end))
p_Ord = log2(p_MaxErr(1:end-1)./p_MaxErr(2:end))