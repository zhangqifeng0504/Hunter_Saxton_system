clear all;close all;clc;
format long e
        a = 4; A = 1; mu = 0.05; sigma = 1;xa = -6; xb = 6;ta = 0; tb = 20;
        h = 1/30; dt = 1/100;
        m = round((xb-xa)/h);
        x = xa:h:xb;  x = x';
        n = round((tb-ta)/dt);
        t = ta:dt:tb; t = t';
        e = ones(m,1);
        M2 = spdiags(e,1-m,m,m)+spdiags(-e,0,m,m)+spdiags(e,1,m,m); % delta_x
[u,rho]=HS_3(A,sigma,mu,a,xa,xb,ta,tb,m,n);
Econs = zeros(1,n+1);
Icons = zeros(1,n+1);
u_semi = (u(2:m+1, :) - u(1:m, :)) / h; % 空间导数
u12 = (u(:,1)+u(:,2))/2;
rho12=(rho(:,1)+rho(:,2))/2;
Econs(1,1) = (h*sum(u_semi(:,1).^2)+h*sum(u_semi(:,2).^2))/2 + (h*sum(rho(2:m+1,1).^2)+h*sum(rho(2:m+1,2).^2))/2 +mu*dt*h*sum(((u12(2:m+1,:)-u12(1:m,:))/h).^2);%mu*dt*h*sum()
for k = 2:n+1
       E_c = (h * sum(u_semi(:,k).^2) + h * sum(u_semi(:,k-1).^2) + ...
           h * sum(rho(2:m+1,k).^2) + h * sum(rho(2:m+1,k-1).^2)) / 2+mu*dt*h*sum(((u12(2:m+1,:)-u12(1:m,:))/h).^2);
    E_a = 0;
    for l = 2:k-1
        rho_bar = (rho(2:m+1,l-1) + rho(2:m+1,l+1)) / 2;
        u_bar = (u(2:m+1,l-1) + u(2:m+1,l+1)) /2;
        u_bar_1 = (M2*u_bar) /h;
        E_a = E_a + h * sum(u_bar_1.^2) + h * sum(rho_bar.^2);
    end
    Econs(1,k) = E_c + 2 * mu * dt * E_a;
    E(1,k) = (h * sum(u_semi(:,k).^2) + h * sum(u_semi(:,k-1).^2) + ...
           h * sum(rho(2:m+1,k).^2) + h * sum(rho(2:m+1,k-1).^2)) / 2+mu*dt*h*sum(((u12(2:m+1,:)-u12(1:m,:))/h).^2);
end
E(1,1) = (h*sum(u_semi(:,1).^2)+h*sum(u_semi(:,2).^2))/2 + (h*sum(rho(2:m+1,1).^2)+h*sum(rho(2:m+1,2).^2))/2 +mu*dt*h*sum(((u12(2:m+1,:)-u12(1:m,:))/h).^2);%mu*dt*h*sum()
     Icons(1,1) =(h*sum(rho(2:m+1,1))+h*sum(rho(2:m+1,2)))/2+mu*dt*h*sum(rho12(2:m+1,:));
 for k=2:n+1
    I_c =(h * sum(rho(2:m+1,k)) + h * sum(rho(2:m+1,k-1))) / 2+mu*dt*h*sum(rho12(2:m+1,:));
    I_a=0;
    for l=2:k-1
         rho_bar = (rho(2:m+1,l-1) + rho(2:m+1,l+1)) / 2; 
         I_a=I_a+h*sum(rho_bar);
    end
    Icons(1,k) =I_c+mu*dt*I_a;  % 
    I(1,k) = (h * sum(rho(2:m+1,k)) + h * sum(rho(2:m+1,k-1))) / 2+mu*dt*h*sum(rho12(2:m+1,:));
 end
 I(1,1) =(h*sum(rho(2:m+1,1))+h*sum(rho(2:m+1,2)))/2+mu*dt*h*sum(rho12(2:m+1,:));
save('x.mat','x')
save('t.mat','t')
save('u.mat','u')
save('rho.mat','rho')
save('Econs.mat','Econs')
save('Icons.mat','Icons')
save('E.mat','E')
save('I.mat','I')