load('x.mat','x')
load('t.mat','t')
load('u.mat','u')
load('rho.mat','rho')
load('Econs.mat','Econs')
load('Icons.mat','Icons')
load('E.mat','E')
load('I.mat','I')
figure(1)
plot(t,Econs,'r-','linewidth',2)
xlabel({'$t$'},'FontUnits','points','interpreter','latex','FontSize',15,'FontName','Times');
hold on;
plot(t,Icons,'b-','linewidth',2)
xlabel({'$t$'},'interpreter','latex','FontSize',15,'FontName','Times');
hold on;
plot(t,E,'r-.','linewidth',2)
xlabel({'$t$'},'FontUnits','points','interpreter','latex','FontSize',15,'FontName','Times');
hold on;
plot(t,I,'b-.','linewidth',2)
xlabel({'$t$'},'interpreter','latex','FontSize',18,'FontName','Times');
legend('$E^k$','$I^k$','$E^k$ with $\lambda$=0','$I^k$ with $\lambda$=0','interpreter','latex','FontSize',16,'FontName','Times','Location','Best');
ylim([0, 15]);
set(gca, 'FontSize', 18, 'FontWeight', 'bold');

figure(2)
plot(t,Econs-Econs(1,1),'r-','linewidth',2)
xlabel({'$t$'},'FontUnits','points','interpreter','latex','FontSize',10,'FontName','Times');
hold on
plot(t,Icons-Icons(1,1),'b-','linewidth',2)
xlabel({'$t$'},'FontUnits','points','interpreter','latex','FontSize',15,'FontName','Times'); legend('$E^k-E^0$','$I^k-I^0$','FontUnits','points','interpreter','latex','FontSize',20,'FontName','Times','Location','Best');
 set(gca, 'FontSize', 18, 'FontWeight', 'bold');
 