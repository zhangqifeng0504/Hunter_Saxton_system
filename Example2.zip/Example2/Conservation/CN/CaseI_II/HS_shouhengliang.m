clear all;close all;clc;
format long e
xa = -6; xb = 6; ta =0; tb = 20; a = 0.1; A = 0; mu = 0; sigma = 1;
%xa = -6; xb = 6; ta =0; tb = 20; a = 0.1; A = 0.1; mu = 0; sigma = 1;%CaseII
        h = 1/30; dt = 1/30;
        m = round((xb-xa)/h);
        n = round((tb-ta)/dt);
        x = xa:h:xb;  x = x';
        t = ta:dt:tb; t = t';
[u,rho]=HS_2(A,sigma,mu,a,xa,xb,ta,tb,m,n);
Econs = zeros(1,n+1);
Icons = zeros(1,n+1);
u_semi = (u(2:m+1,:)-u(1:m,:))/h;
for k = 2:n+1
    E_c=h*sum(u_semi(:,k).^2)+h*sum(rho(2:m+1,k).^2);
    E_a=0;
    for l=1:k-1
        u_half_l = (u(2:m+1,l) + u(2:m+1,l+1))/2; % u^{l+1/2}
        u_half_2 = (u_half_l(2:end,:)-u_half_l(1:end-1,:))/ h;
        rho_half_l = (rho(2:m+1,l) + rho(2:m+1,l+1)) / 2; % rho^{l+1/2}
         E_a = E_a + h * sum(u_half_2.^2) + h * sum(rho_half_l.^2);
    end
    Econs(1,1)=h*sum(u_semi(:,1).^2)+h*sum(rho(2:m+1,1).^2);
    Econs(1,k) = E_c+2*mu*dt*E_a; % E^k
end
 for k=2:n+1
    I_c =h*sum(rho(2:m+1,k));
    I_a=0;
    for l=1:k-1
         rho_half_l =(rho(2:m+1,l)+rho(2:m+1,l+1))/2; 
         I_a=I_a+h*sum(rho_half_l);
    end
    Icons(1,1) = h*sum(rho(2:m+1,1));
    Icons(1,k) =I_c+mu*dt*I_a;  % I^k
    end 
save('x.mat','x')
save('t.mat','t')
save('u.mat','u')
save('rho.mat','rho')
save('Econs.mat','Econs')
save('Icons.mat','Icons')
