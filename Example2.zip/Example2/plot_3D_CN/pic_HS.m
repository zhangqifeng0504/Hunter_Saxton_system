%% 三维图
clear all; close all; clc;
format long e
xa = -6; xb = 6; ta =0; tb = 20; a = 0.1; A = 0; mu = 0; sigma = 1;%CaseI
%xa = -6; xb = 6; ta =0; tb = 20; a = 0.1; A = 0.1; mu = 0; sigma = 1;%CaseII
%xa = -6; xb = 6; ta =0; tb = 20; a = 0.1; A = 0.1; mu = 0.015; sigma = 1;%CaseIII
%xa = -6; xb = 6; ta =0; tb = 20; a = 4; A = 0; mu = 0; sigma = 1;%CaseIV
%xa = -6; xb = 6; ta =0; tb = 20; a = 4; A = 1; mu = 0; sigma = 1;%CaseV
%xa = -6; xb = 6; ta =0; tb = 20; a = 4; A = 1; mu = 0.05; sigma = 1;%CaseVI
        h = 1/30; dt = 1/30;
        m = round((xb-xa)/h);
        n = round((tb-ta)/dt);
        x = xa:h:xb;  x = x';
        t = ta:dt:tb; t = t'; 
[u,p]=HS_2(A,sigma,mu,a,xa,xb,ta,tb,m,n);
t1 = t(1:12:end); u1 = u(:,1:12:end); p1 = p(:,1:12:end);
figure(1)
mesh(x, t1, u1'); view([90 90])
xlabel('$x$', 'FontUnits', 'points', 'interpreter', 'latex', 'FontSize', 16, 'FontName', 'Times', 'FontWeight', 'bold'); 
ylabel('$t$', 'FontUnits', 'points', 'interpreter', 'latex', 'FontSize', 16, 'FontName', 'Times', 'FontWeight', 'bold');
zlabel('$u$', 'FontUnits', 'points', 'interpreter', 'latex', 'FontSize', 16, 'FontName', 'Times', 'FontWeight', 'bold');
title('$u$', 'FontUnits', 'points', 'interpreter', 'latex', 'FontSize', 25, 'FontName', 'Times', 'FontWeight', 'bold');
axis([-6 6 0 20])
set(gca, 'FontSize', 25,'FontWeight', 'bold');
colorbar('FontSize', 16, 'FontWeight', 'bold'); % Add color bar
figure(2)
mesh(x, t1, p1'); view([90 90])
xlabel('$x$', 'FontUnits', 'points', 'interpreter', 'latex', 'FontSize', 25, 'FontName', 'Times', 'FontWeight', 'bold'); 
ylabel('$t$', 'FontUnits', 'points', 'interpreter', 'latex', 'FontSize', 25, 'FontName', 'Times', 'FontWeight', 'bold'); 
zlabel('$\mathbf{\rho}$', 'FontUnits', 'points', 'interpreter', 'latex', 'FontSize', 25, 'FontName', 'Times', 'FontWeight', 'bold');
title('$\rho$', 'FontUnits', 'points', 'interpreter', 'latex', 'FontSize', 25, 'FontName', 'Times', 'FontWeight', 'bold');
axis([-6 6 0 20])
set(gca, 'FontSize', 25,'FontWeight', 'bold');
colorbar('FontSize', 16, 'FontWeight', 'bold'); % Add color bar
