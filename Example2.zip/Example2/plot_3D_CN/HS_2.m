function [u,rho]=HS_2(A,sigma,mu,a,xa,xb,ta,tb,m,n)
%% Mesh generation
h = (xb-xa)/m;
dt = (tb-ta)/n;
x = xa:h:xb; x = x';
u = zeros(m+1,n+1);
rho = zeros(m+1,n+1);
%% Initial condition
% u(:,1) = exp(-abs(x));
% rho(:,1) = 0.5;
% u(:,1) = 1/(2*sinh(1/4))*sinh(x).*(x>=0 & x<= 1/4)...
%         +1/(sinh(-1/2))*sinh(x-1/2).*(x>1/4 & x<=3/4)...
%         +1/(2*sinh(1/4))*sinh(x-1).*(x>3/4 & x<1);
% rho(:,1) = 1.5;
u(:,1) = 0;
rho(:,1) = 1+tanh(x+a)-tanh(x-a);
%% Operator matrix
e = ones(m,1);
M1 = spdiags(e,1-m,m,m)+spdiags(e,-1,m,m)+spdiags(-2*e,0,m,m)+spdiags(e,1,m,m)+spdiags(e,m-1,m,m); % delta_x^2
M2 = spdiags(e,1-m,m,m)+spdiags(-e,-1,m,m)+spdiags(e,1,m,m)+spdiags(-e,m-1,m,m); % Delta_x
%% The main function
ite = 0;
for k = 1:n
    C1 = -2/(dt*h^2)*M1;
    C2 = -A/(2*h)*M2-mu/(h^2)*M1;
    y = u(2:m+1,k); z = rho(2:m+1,k); % Initial iteration value
    epsilon = 1;
    while epsilon > 1e-6
       y1 = y; z1 = z;
       v = 1/h^2*M1*y;
       C3 = -sigma/(2*h)*(v.*speye(m)*M2+PerioMat(v))-dt/(4*(2+mu*dt)*h^2)*z.*speye(m)*M2*PerioMat(z);
       D = C1*u(2:m+1,k)-1/((mu*dt+2)*h)*z.*speye(m)*M2*rho(2:m+1,k);
       y = (C1+C2+C3)\D;
       z = 2/(2+mu*dt)*rho(2:m+1,k)-dt/(2*(2+mu*dt)*h)*PerioMat(z)*y;
       epsilon = max(max(abs(y1-y)),max(abs(z1-z)));
       ite = ite+1;
    end
    u(2:m+1,k+1) = 2*y-u(2:m+1,k); u(1,k+1) = u(m+1,k+1);
    rho(2:m+1,k+1) = 2*z-rho(2:m+1,k); rho(1,k+1) = rho(m+1,k+1);
end
ave = ite/n
function M = PerioMat(w)
M = spdiags(-w,-1,m,m)+spdiags(w,1,m,m);
M(1,m) = -w(end); M(m,1) = w(1);
end
end