function [u,rho,uax_err,pax_err]=HS_3(A,sigma,mu,xa,xb,ta,tb,m,n)
%% Mesh generation
h = (xb-xa)/m;
dt = (tb-ta)/n;
x = xa:h:xb; x = x';
t = ta:dt:tb;a=3;
u = zeros(m+1,n+1);
rho = zeros(m+1,n+1);
%% Initial condition
c1 = @(x,t) exp(-a*t).*sin(x); 
Err1=zeros(m+1,n+1);Err2=zeros(m+1,n+1);
c2 = @(x,t) sqrt(3*sigma).*exp(-a*t).*cos(x);
rho(:,1) = c2(x,t(1));
u(:,1) = c1(x,t(1));
f=zeros(m+1,n+1);
g=zeros(m+1,n+1);
for k=1:n+1
    for i=1:m+1
         f(i,k)=(mu-a)*exp(-a*t(k))*sin(x(i)) - A*exp(-a*t(k))*cos(x(i));
         g(i,k)=sqrt(3*sigma)*exp(-2*a*t(k))*cos(2*x(i)) + (mu-a)*sqrt(3*sigma)*exp(-a*t(k))*cos(x(i));
    end
end
%% Operator matrix
e = ones(m,1);
M1 = spdiags(e,1-m,m,m)+spdiags(e,-1,m,m)+spdiags(-2*e,0,m,m)+spdiags(e,1,m,m)+spdiags(e,m-1,m,m); % delta_x^2
M2 = spdiags(e,1-m,m,m)+spdiags(-e,-1,m,m)+spdiags(e,1,m,m)+spdiags(-e,m-1,m,m); % Delta_x
%% The main function
C1 = -2/(dt*h^2)*M1;
C2 = -A/(2*h)*M2-mu/(h^2)*M1;
% 1_st level
y = u(2:m+1,1); z = rho(2:m+1,1);
v = 1/h^2*M1*y;
C3 = -sigma/(2*h)*(v.*speye(m)*M2+M2*diag(v))-dt/(4*(2+dt*mu)*h^2)*z.*speye(m)*M2*M2*diag(z);
D = C1*y-1/((2+dt*mu)*h)*z.*speye(m)*M2*(z+dt/4*(g(2:m+1,1)+g(2:m+1,2)))+1/2*(f(2:m+1,1)+f(2:m+1,2));
u_frac12 = (C1+C2+C3)\D;
rho_frac12 = 2/(2+mu*dt)*(z+(dt/4)*(g(2:m+1,1)+g(2:m+1,2)))-dt/(2*(2+mu*dt)*h)*M2*diag(z)*u_frac12;
u(2:m+1,2) = 2*u_frac12-y; u(1,2) = u(m+1,2);
rho(2:m+1,2) = 2*rho_frac12-z; rho(1,2) = rho(m+1,2);
% k+1_th level
for k = 2:n
    y = u(2:m+1,k); z = rho(2:m+1,k); 
    v = 1/h^2*M1*y;
    C3 = -sigma/(2*h)*(v.*speye(m)*M2+M2*diag(v))-dt/(4*(1+mu*dt)*h^2)*z.*speye(m)*M2*M2*diag(z);
    D = 1/2*C1*u(2:m+1,k-1)-1/((1+mu*dt)*2*h)*z.*speye(m)*M2*(rho(2:m+1,k-1)+dt*g(2:m+1,k))+f(2:m+1,k);
    u_k_bar = (1/2*C1+C2+C3)\D;
    rho_k_bar = 1/(1+mu*dt)*(rho(2:m+1,k-1)+dt*g(2:m+1,k))-dt/(2*(1+mu*dt)*h)*M2*diag(z)*u_k_bar;
    u(2:m+1,k+1) = 2*u_k_bar-u(2:m+1,k-1); u(1,k+1) = u(m+1,k+1);
    rho(2:m+1,k+1) = 2*rho_k_bar-rho(2:m+1,k-1); rho(1,k+1) = rho(m+1,k+1);
end
U=zeros(m+1,n+1);P=zeros(m+1,n+1);
for i = 1:m+1
    for k=1:n+1
        U(i,k)= sin(x(i))*exp(-a*t(k)); 
        P(i,k) = sqrt(3*sigma)*cos(x(i))*exp(-a*t(k));
    end
end
% ave = ite/n
Err1 =abs(U-u);
uax_err = max(max(Err1));
pax_err = max(sqrt((abs(xb-xa)/m)*sum((P - rho).^2)));
function M = PerioMat(w)
M = spdiags(-w,-1,m,m)+spdiags(w,1,m,m);
M(1,m) = -w(end); M(m,1) = w(1);
end
end
