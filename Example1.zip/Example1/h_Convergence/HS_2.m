function [u,rho,uax_err,pax_err]=HS_2(A,sigma,mu,xa,xb,ta,tb,m,n)
%% Mesh generation
h = (xb-xa)/m;
dt = (tb-ta)/n;a=3;
x = xa:h:xb; x = x';
t = ta:dt:tb;
u = zeros(m+1,n+1);
rho = zeros(m+1,n+1);
%% Initial condition
c1 = @(x,t) exp(-a*t).*sin(x); 
c2 = @(x,t) sqrt(3*sigma).*exp(-a*t).*cos(x);
rho(:,1) = c2(x,t(1));
u(:,1) = c1(x,t(1));
f=zeros(m+1,n+1);
g=zeros(m+1,n+1);
for k=1:n+1
    for i=1:m+1
         f(i,k)=(mu-a)*exp(-a*t(k))*sin(x(i))-A*exp(-a*t(k))*cos(x(i));
         g(i,k)=sqrt(3*sigma)*exp(-2*a*t(k))*cos(2*x(i)) + (mu-a)*sqrt(3*sigma)*exp(-a*t(k))*cos(x(i));
    end
end
%% Operator matrix
e = ones(m,1);
M1 = spdiags(e,1-m,m,m)+spdiags(e,-1,m,m)+spdiags(-2*e,0,m,m)+spdiags(e,1,m,m)+spdiags(e,m-1,m,m); % delta_x^2
M2 = spdiags(e,1-m,m,m)+spdiags(-e,-1,m,m)+spdiags(e,1,m,m)+spdiags(-e,m-1,m,m); % Delta_x
M3 = spdiags(-2*e,1-m,m,m)+spdiags(e,2-m,m,m)+spdiags(-e,-2,m,m)+spdiags(2*e,-1,m,m)...
    +spdiags(-2*e,1,m,m)+spdiags(e,2,m,m)+spdiags(-e,m-2,m,m)+spdiags(2*e,m-1,m,m); % Delta_x delta_x^2
%% The main function
ite = 0;
for k = 1:n
    C1 = -(2/(dt*h^2))*M1;
    C2 = -(A/(2*h))*M2-(mu/(h^2))*M1;
    y = u(2:m+1,k); z = rho(2:m+1,k); % Initial iteration value
    epsilon = 1;
    while epsilon > 1e-6
        y1 = y; z1 = z;
       v = 1/h^2*M1*y;
       C3 = -sigma/(2*h)*(1/h^2*M1*y.*speye(m)*M2+M2*diag(1/h^2*M1*y))-dt/(4*(2+mu*dt)*h^2)*z.*speye(m)*M2*M2*diag(z);
       D = C1*u(2:m+1,k)-1/((mu*dt+2)*h)*z.*speye(m)*M2*(rho(2:m+1,k)+dt/4*(g(2:m+1,k)+g(2:m+1,k+1)))+1/2*(f(2:m+1,k)+f(2:m+1,k+1));
       y = (C1+C2+C3)\D;
       z = 2/(2+mu*dt)*(rho(2:m+1,k)+dt/4*(g(2:m+1,k)+g(2:m+1,k+1)))-dt/(2*(2+mu*dt)*h)*M2*diag(z)*y;
       epsilon = max(max(abs(y1-y)),max(abs(z1-z)));
       ite = ite+1;
    end
    u(2:m+1,k+1) = 2*y-u(2:m+1,k); u(1,k+1) = u(m+1,k+1);
    rho(2:m+1,k+1) = 2*z-rho(2:m+1,k); rho(1,k+1) = rho(m+1,k+1);
end
U=zeros(m+1,n+1);P=zeros(m+1,n+1);
for i = 1:m+1
    for k=1:n+1
        U(i,k)= sin(x(i))*exp(-a*t(k)); 
        P(i,k) = sqrt(3*sigma)*cos(x(i))*exp(-a*t(k));
    end
end
% ave = ite/n
Err1 =abs(U-u);
uax_err = max(max(Err1));
pax_err = max(sqrt((abs(xb-xa)/m)*sum((P - rho).^2)));
%ave = ite/n
function M = PerioMat(w)
M = spdiags(-w,-1,m,m)+spdiags(w,1,m,m);
M(1,m) = -w(end); M(m,1) = w(1);
end
end