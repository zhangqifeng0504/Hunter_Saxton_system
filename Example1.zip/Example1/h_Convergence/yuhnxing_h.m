%% 空间阶
clear all; clc; format short e
n =1000; 
xa = 0; xb = 2*pi; ta =0; tb = 1; A = 0; mu = 0; sigma = 1;%CaseI
%xa = 0; xb = 2*pi; ta =0; tb = 1; A = 1; mu = 0; sigma = 1;%CaseII
%xa = 0; xb = 2*pi; ta =0; tb = 1; A = 1; mu = 3; sigma = 1;%CaseIII
for i = 1:5
    tic
    m =10*2.^(i-1); 
    [u,rho,uax_err,pax_err]=HS_2(A,sigma,mu,xa,xb,ta,tb,m,n);
    %[u,rho,uax_err,pax_err]=HS_3(A,sigma,mu,xa,xb,ta,tb,m,n);
    u_MaxErr(i) = uax_err
    p_MaxErr(i) = pax_err
    cputime(i)=toc;
end
u_Ord = log2(u_MaxErr(1:end-1)./u_MaxErr(2:end))
p_Ord = log2(p_MaxErr(1:end-1)./p_MaxErr(2:end))