clear all; close all; clc;

% Parameters (using Case V)
A = 0; mu = 0; sigma = 1; %CaseI
%A = 0.1; mu = 0; sigma = 1;%CaseII
%A = 0.1; mu = 0.1; sigma = 1;%CaseIII
xa = -20; xb = 20;
h = 1/50; dt = 1/100;
ta = 0;
m = round((xb-xa)/h);
x = xa:h:xb; x = x';

% Define the specific time points you want to capture
time_points = [1, 4, 7, 10];
tb = max(time_points); % Run simulation until the last time point
n = round((tb-ta)/dt);
% Run the simulation
[u, rho] = HS_2nianxing(A, sigma, mu, xa, xb, ta, tb, m, n);
% Find the indices corresponding to the time points
time_indices = round(time_points / dt) + 1;
% Plot results for each time point
for i = 1:length(time_points)
    % Get current u and rho data
    u_data = u(:, time_indices(i));
    rho_data = rho(:, time_indices(i));
    
    % Calculate y-axis limits with some padding (10% buffer)
    u_min = min(u_data) - 0.1 * abs(min(u_data));
    u_max = max(u_data) + 0.1 * abs(max(u_data));
    rho_min = min(rho_data) - 0.1 * abs(min(rho_data));
    rho_max = max(rho_data) + 0.1 * abs(max(rho_data));
    % Ensure non-empty range (if data is constant)
    if u_min == u_max
        u_min = u_min - 0.1;
        u_max = u_max + 0.1;
    end
    if rho_min == rho_max
        rho_min = rho_min - 0.1;
        rho_max = rho_max + 0.1;
    end
    
    % Plot u at specific time
    figure(2*i-1);
    plot(x, u_data, 'b', 'LineWidth', 1);
    set(gca, 'FontSize', 15);
    title(sprintf('$u(x,%.0f)$', time_points(i)), 'interpreter', 'latex', 'FontName', 'Times', 'FontSize', 25);
    set(gca, 'xTick', [-20, -10, 0, 10, 20]);
    set(gca, 'XTickLabel', {'-20', '-10', '0', '10', '20'});
    ylim([u_min, u_max]); % Set y-axis limits for u
    
    % Plot rho at specific time
    figure(2*i);
    plot(x, rho_data, 'b', 'LineWidth', 1);
    set(gca, 'FontSize', 15);
    title(sprintf('$\\rho(x,%.0f)$', time_points(i)), 'interpreter', 'latex', 'FontName', 'Times', 'FontSize', 25);
    set(gca, 'xTick', [-20, -10, 0, 10, 20]);
    set(gca, 'XTickLabel', {'-20', '-10', '0', '10', '20'});
    ylim([rho_min, rho_max]); % Set y-axis limits for rho
end