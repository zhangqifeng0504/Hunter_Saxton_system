clear all;close all;clc;
format long e 
        A =0; mu = 0; sigma = 1;xa = -20; xb = 20;ta =0; tb =50;%CaseI
       %xa = -20; xb = 20;ta =0; tb =50; A = 0.1; mu = 0; sigma = 1;%CaseII
        h = 1/30; dt = 1/30;
        m = round((xb-xa)/h);
        n = round((tb-ta)/dt);
        x = xa:h:xb;  x = x';
        t = ta:dt:tb; t = t';
        e = ones(m,1);
        M2 = spdiags(e,1-m,m,m)+spdiags(-e,0,m,m)+spdiags(e,1,m,m); % Delta_x
[u,rho]=HS_2(A,sigma,mu,xa,xb,ta,tb,m,n);
Econs = zeros(1,n+1);
Icons = zeros(1,n+1);
u_semi = (M2*u(2:m+1,:))/h;
for k = 1:n+1
    E_c=fun(u_semi(:,k),u_semi(:,k),h)+fun(rho(2:m+1,k),rho(2:m+1,k),h);
    E_a=0;
    for l = 1:k-1
        u_1= (u(2:m+1,l+1) + u(2:m+1,l))/2; % u^{l+1/2}
        u_2 = (M2*u_1)/ h;
        rho_half_l = (rho(2:m+1,l) + rho(2:m+1,l+1)) / 2; % rho^{l+1/2}
        E_a = E_a + (fun(u_2,u_2,h) + fun(rho_half_l,rho_half_l,h));
      end
    Econs(1,k) = E_c+2*mu*dt*E_a; % E^k
    E(1,k)=h*sum(u_semi(:,k).^2)+h*sum(rho(2:m+1,k).^2);
 %for k=2:n+1
    I_c =h*sum(rho(2:m+1,k));
   I_a=0;
   for l=1:k-1
        rho_half_l =(rho(2:m+1,l)+rho(2:m+1,l+1))/2; 
         I_a=I_a+mu*dt*fun(rho_half_l,1,h);
    end
       Icons(1,k) =I_c+I_a;  % I^k
  I(1,k)=h*sum(rho(2:m+1,k));  
end 
save('x.mat','x')
save('t.mat','t')
save('u.mat','u')
save('rho.mat','rho')
save('Econs.mat','Econs')
save('Icons.mat','Icons')
save('E.mat','E')
save('I.mat','I')

function I = fun(u, v, hx)
    I = sum(u .* v, 1) * hx;
end